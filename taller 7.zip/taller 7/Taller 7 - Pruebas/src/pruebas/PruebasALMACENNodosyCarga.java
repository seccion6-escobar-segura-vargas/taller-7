package pruebas;

import static org.junit.jupiter.api.Assertions.*;


import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.cupi2.almacen.mundo.Almacen;
import uniandes.cupi2.almacen.mundo.AlmacenException;
import uniandes.cupi2.almacen.mundo.Categoria;
import uniandes.cupi2.almacen.mundo.NodoAlmacen;

class PruebasALMACENNodosyCarga 
{
	private Almacen almacenPruebas;
	private Almacen almacenVacioPruebas;
	

	@BeforeEach
	void setUp() throws Exception 
	{
		almacenPruebas = new Almacen(new File("./data/datos.txt"));
		almacenVacioPruebas = new Almacen(new File("./data/datosVacio.txt"));
		
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		
		
	}

	@Test
	void testCarga() 
	{
		//fail("Not yet implemented");
		List <NodoAlmacen> nodos21 = almacenPruebas.darCategoriaRaiz().darPreorden();
		
		List <NodoAlmacen> nodos1 = almacenVacioPruebas.darCategoriaRaiz().darPreorden();
		
		assertEquals(21, nodos21.size(), "La cantidad de categorias deber�a ser 21.");
		
		assertEquals(1, nodos1.size(), "La cantidad de categorias del vacio deber�a ser 1.");
		
	}
	
	
	@Test
	void testIntentarCargarArchivoIncorrecto()
	{
		try 
		{
			new Almacen(new File("./data/datosVacioError.txt"));
			fail("No se ha identificado cuando el archivo a leer tiene errores con respecto a los nodos.");
		}
		catch(AlmacenException ae)
		{
			//todo bien
		}
		
		
	}
	
	
	@Test
	void testDarRaiz() 
	{
		//fail("Not yet implemented");
		Categoria raiz = almacenPruebas.darCategoriaRaiz();
		
		assertEquals("Cupi2", raiz.darNombre(), "El nombre de la raiz deberia ser Cupi2.");
		assertEquals(2, raiz.darNodos().size(), "El numero de nodos hijos de la raiz deberia ser 2.");
		assertEquals("1", raiz.darIdentificador(), "El identificador de la raiz deberia ser 1.");
		
		
	}
	
	@Test
	void testBuscarNodo()
	{
		HashMap<String, String> mapaIDs_nombres = new HashMap<String, String>();
		
		for (NodoAlmacen nodo: almacenPruebas.darCategoriaRaiz().darPreorden())
		{
			String nombre = nodo.darNombre();
			String id = nodo.darIdentificador();
			mapaIDs_nombres.put(id, nombre);
			
			
		//	System.out.println(id+"-"+ nombre);
		}
		
		
		//System.out.println("yaaaaa");
		for(String id: mapaIDs_nombres.keySet())
		{
			NodoAlmacen nodoEncontrado = almacenPruebas.buscarNodo(id);
			String nombreNodoEncontrado = nodoEncontrado.darNombre();
			
			String nombreCargado = mapaIDs_nombres.get(id);
		//	System.out.println(nombreNodoEncontrado+"-"+ nombreCargado);
			assertEquals(nombreCargado, nombreNodoEncontrado, "El nombre del nodo "+id+" deberia ser "+nombreCargado);
		}
	
	}
	
	
	@Test
	void testEliminarNodo()
	{
		
		List<NodoAlmacen> hijos = almacenPruebas.darCategoriaRaiz().darPosorden();
		
		while(hijos.size()>1)
		{
			int siguiente = (int)(Math.random()*(hijos.size()-1));
			
			if(siguiente >= 1)
			{
				NodoAlmacen nodo = hijos.get(siguiente);
				
				try
				{
					almacenPruebas.eliminarNodo(nodo.darIdentificador());
				}
				catch(AlmacenException ae)
				{
					fail("No deberia generarse una excepcion de almacen porque se est�"
							+ " eliminando un nodo existente distinto de la ra�z.");
				}
				
				hijos = almacenPruebas.darCategoriaRaiz().darPosorden();
				assertFalse(hijos.contains(nodo), "El nodo "+nodo.darIdentificador()+"no fue eliminado correctamente.");
				
			}
			
			
			
		}
		assertEquals(1, almacenPruebas.darCategoriaRaiz().darPosorden().size(), "Solo deber�a quedar la ra�z.");
		
	}	
	
	

	@Test
	void testIntentarEliminarRaiz()
	{
		
		Categoria cateRaiz = almacenPruebas.darCategoriaRaiz();
		
		try
		{
			almacenPruebas.eliminarNodo(cateRaiz.darIdentificador());
			
			fail("No se ha generado correctamente una excepcion de almacen cuando se "
					+ "intenta eliminar el nodo ra�z.");
			
		}
		catch(AlmacenException ae)
		{
			//bien hecho
		}
		
		
	}
	
	@Test
	void testAgregarNodo()
	{
		String idCate1 = "1";
		String idCate2 = "11";
		String idCate3 = "111";

		int tama�oOriginal = almacenPruebas.darCategoriaRaiz().darPosorden().size();
		//System.out.println(tama�oOriginal);
		int i = 0 ;
		while(  i<30 )
		{
	
			Integer fi = i+90000000;
			Integer gi = fi*3;
			
			try 
			{
				if (i>25)
				{
					almacenPruebas.agregarNodo( idCate1, "Categoria",  fi.toString(), gi.toString() );
				}
				else if(i>20)
				{
					
					almacenPruebas.agregarNodo( idCate1, "Marca",  fi.toString(), gi.toString() );
					
				}
				else if (i>15)
				{
					
					almacenPruebas.agregarNodo( idCate2, "Categoria",  fi.toString(), gi.toString() );
					
				}
				else if (i>10)
				{
					
					almacenPruebas.agregarNodo( idCate2, "Marca",  fi.toString(), gi.toString() );
					
				}
				else if (i>5)
				{
					
					almacenPruebas.agregarNodo( idCate3, "Categoria",  fi.toString(), gi.toString() );
					
				}
				else 
				{
					
					almacenPruebas.agregarNodo( idCate3, "Marca",  fi.toString(), gi.toString() );
					
				}
				
				
				
				
			} 
			catch (AlmacenException ae) 
			{
				
				fail("No se ha podido agregar correctamente el nodo.");
				
			}
			
			
			 i = i + 1;
			 
			 
			 
			
			 NodoAlmacen nodoEncontrado = almacenPruebas.buscarNodo(fi.toString());
			 assertFalse(nodoEncontrado==null, "No se ha agregado el nodo con identificador "+fi.toString());
			 assertEquals(nodoEncontrado.darNombre(), gi.toString(), "El nodo con "
			 		+ "identificador "+fi.toString()+" no se ha agregado con el nombre correcto "+gi.toString());
		 
		
			
		}
		//System.out.println(almacenPruebas.darCategoriaRaiz().darPosorden().size());
		assertEquals(tama�oOriginal+30, almacenPruebas.darCategoriaRaiz().darPosorden().size(), "Se debieron haber agregado 10 nodos");
		
		
	}
	
	
	
	
	
	
	@Test
	void testExtensionMetodo1()
	{
		assertEquals("Respuesta 1", almacenPruebas.metodo1(), "Respuesta incorrecta para metodo de extension 1");
	}
	

	@Test
	void testExtensionMetodo2()
	{
		assertEquals("Respuesta 2", almacenPruebas.metodo2(), "Respuesta incorrecta para metodo de extension 2");
	}
	
	
	
	
	

}























